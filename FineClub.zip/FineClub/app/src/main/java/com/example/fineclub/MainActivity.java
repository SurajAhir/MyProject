package com.example.fineclub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.fineclub.Fragments.Login;
import com.example.fineclub.Fragments.SignUp;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
FragmentContainerView containerView;
BottomNavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        containerView=findViewById(R.id.fragment_container_view);
        navigationView=findViewById(R.id.bottom_navigation_view);
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container_view,new SignUp());
        transaction.commit();
        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                FragmentTransaction transaction1=getSupportFragmentManager().beginTransaction();
                switch (item.getItemId()){
                    case R.id.sign_up_menu_button:
                        transaction1.replace(R.id.fragment_container_view,new SignUp());
                        transaction1.commit();
                        break;
                    case R.id.login_menu_button:
                        transaction1.replace(R.id.fragment_container_view,new Login());
                        transaction1.commit();
                        break;

                }

                return true;
            }
        });
    }
}