package com.example.fineclub;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.fineclub.Fragments.Home;
import com.example.fineclub.Fragments.Leads;
import com.example.fineclub.Fragments.Login;
import com.example.fineclub.Fragments.Profile;
import com.example.fineclub.Fragments.Referral;
import com.example.fineclub.Fragments.Training;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ShowFragmentsActivity extends AppCompatActivity {
FragmentContainerView containerView;
BottomNavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_fragments);
        containerView=findViewById(R.id.show_fragment_containerView);
        navigationView=findViewById(R.id.show_fragment_bottom_navigation_view);
        FragmentTransaction transaction=getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.show_fragment_containerView,new Home());
        transaction.commit();
        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                FragmentTransaction transaction1=getSupportFragmentManager().beginTransaction();
                switch (item.getItemId()){
                    case R.id.show_fragment_home:
                        transaction1.replace(R.id.show_fragment_containerView,new Home());
                        transaction1.commit();
                        break;
                    case R.id.show_fragment_training:
                        transaction1.replace(R.id.show_fragment_containerView,new Training());
                        transaction1.commit();
                        break;
                    case R.id.show_fragment_leads:
                        transaction1.replace(R.id.show_fragment_containerView,new Leads());
                        transaction1.commit();
                        break;
                    case R.id.show_fragment_referral:
                        transaction1.replace(R.id.show_fragment_containerView,new Referral());
                        transaction1.commit();
                        break;
                    case R.id.show_fragment_profile:
                        transaction1.replace(R.id.show_fragment_containerView,new Profile());
                        transaction1.commit();
                        break;
                }


                return  true;
            }
        });
    }
}