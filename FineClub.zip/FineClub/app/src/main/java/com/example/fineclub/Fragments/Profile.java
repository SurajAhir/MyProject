package com.example.fineclub.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.fineclub.R;
import com.example.fineclub.ShowBankDetails;
import com.example.fineclub.ShowPersonalDetails;

public class Profile extends Fragment {
TextView personalDetails,bankingDetails;
    public Profile() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_profile, container, false);
        personalDetails= view.findViewById(R.id.profile_personal_details_btn);
        bankingDetails=view.findViewById(R.id.profile_banking_details_btn);
        bankingDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getContext(), ShowBankDetails.class);
                startActivity(intent);
            }
        });
        personalDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getContext(), ShowPersonalDetails.class);
                startActivity(intent);
            }
        });
        return view;
    }
}