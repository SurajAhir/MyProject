package com.example.fineclub.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fineclub.R;
import com.example.fineclub.ViewPagerLayouts.HowTo;
import com.example.fineclub.ViewPagerLayouts.Trainings;
import com.google.android.material.tabs.TabLayout;

public class Training extends Fragment {
ViewPager viewPager;
TabLayout tabLayout;
    public Training() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

       View view= inflater.inflate(R.layout.fragment_training, container, false);
   viewPager=view.findViewById(R.id.training_viewpager);
   tabLayout=view.findViewById(R.id.training_tablayout);
   viewPager.setAdapter(new ViewPagerAdapter(getParentFragmentManager()));
   tabLayout.setupWithViewPager(viewPager);


return view;
    }
}
class ViewPagerAdapter extends FragmentPagerAdapter {

    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                return new HowTo();
            case 1:
                return new Trainings();
            default:return new HowTo();
        }

    }

    @Override
    public int getCount() {
        return 2;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title="";
        switch (position){
            case 0:
                title="HOW TO";
                break;
            case 1:
                title="TRAININGS";
                break;
            default:title="HOW TO";
        }
        return title;
    }
}