package com.example.fineclub.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.fineclub.R;
import com.example.fineclub.ViewPagerLayouts.Complet;
import com.example.fineclub.ViewPagerLayouts.HowTo;
import com.example.fineclub.ViewPagerLayouts.Pending;
import com.example.fineclub.ViewPagerLayouts.Rejected;
import com.example.fineclub.ViewPagerLayouts.Trainings;
import com.google.android.material.tabs.TabLayout;

public class Leads extends Fragment {
    ViewPager viewPager;
    TabLayout tabLayout;
    public Leads() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_leads, container, false);
        viewPager=view.findViewById(R.id.lead_viewpager);
        tabLayout=view.findViewById(R.id.lead_tablayout);
        viewPager.setAdapter(new LeadViewPagerAdapter(getParentFragmentManager()));
        tabLayout.setupWithViewPager(viewPager);


        return view;
    }
}
class LeadViewPagerAdapter extends FragmentPagerAdapter {

    public LeadViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                return new Complet();
            case 1:
                return new Pending();
            case 2:
                return new Rejected();
            default:return new Complet();
        }

    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String title="";
        switch (position){
            case 0:
                title="COMPLET";
                break;
            case 1:
                title="PENDING";
                break;
            case 2:
                title="REJECTED";
            default:title="COMPLET";
        }
        return title;
    }
}