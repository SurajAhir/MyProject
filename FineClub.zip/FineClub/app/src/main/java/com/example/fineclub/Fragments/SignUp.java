package com.example.fineclub.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.fineclub.R;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import java.util.ArrayList;

public class SignUp extends Fragment {
//Spinner spinner;
SearchableSpinner spinner;
ArrayList<String>list=new ArrayList<>();
    public SignUp() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragment_sign_up, container, false);
//spinner=view.findViewById(R.id.spinner);
spinner=view.findViewById(R.id.spinner);
list.add("Andaman and Nicobar Islands");
list.add("Andhra Pradesh");
list.add("Arunachal Pradesh");
list.add("Assam");
list.add("Bihar");
list.add("Chandigarh");
list.add("Chhattisgarh");
list.add("Dadra and Nagar Haveli");
list.add("Daman and Diu");
list.add("Delhi");
list.add("Goa");
list.add("Gujarat");
list.add("Haryana");
spinner.setTitle("Select State");
spinner.setAdapter(new ArrayAdapter<String >(getContext(), android.R.layout.simple_spinner_dropdown_item,list));
spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
});


        return view;
    }
}